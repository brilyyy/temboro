<?php $__env->startSection('content'); ?>
<h1 class="mt-4">Create Post</h1>
<ol class="breadcrumb mb-4">
    <li class="breadcrumb-item active">Post</li>
</ol>
<form action="<?php echo e(route('create.post.service')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
        <label for="exampleFormControlInput1" class="form-label fw-bold">Title</label>
        <input type="text" class="form-control" id="exampleFormControlInput1" name="title" autocomplete="off">
    </div>
    <div class="mb-3">
        <label for="selectCat" class="form-label fw-bold">Category</label>
        <select id="selectCat" class="form-select mb-3" aria-label="Default select example" name="tag_id">
            <option selected>Category</option>
            <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($tag->id); ?>"><?php echo e($tag->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="mb-3">
        <label for="formFile" class="form-label fw-bold">Header</label>
        <input class="form-control" type="file" id="formFile" name="header">
    </div>
    <div class="mb-3">
        <label for="editor" class="form-label fw-bold">Content</label>
        <textarea class="form-control editor" name="desc"></textarea>
    </div>
    <button class="btn btn-primary" type="submit">Save</button>
</form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('ck-editor'); ?>
<script src="<?php echo e(asset('assets/cke/ckeditor.js')); ?>"></script>
<script>
    ClassicEditor
    .create( document.querySelector( '.editor' ), {
    toolbar: {
    items: [
    'heading',
    '|',
    'alignment',
    'bold',
    'italic',
    'link',
    'bulletedList',
    'numberedList',
    '|',
    'outdent',
    'indent',
    '|',
    'imageUpload',
    'blockQuote',
    'insertTable',
    'mediaEmbed',
    'undo',
    'redo'
    ]
    },
    language: 'en',
    image: {
    toolbar: [
    'imageTextAlternative',
    'imageStyle:inline',
    'imageStyle:block',
    'imageStyle:side'
    ]
    },
    table: {
    contentToolbar: [
    'tableColumn',
    'tableRow',
    'mergeTableCells'
    ]
    },
    licenseKey: '',



    } )
    .then( editor => {
    window.editor = editor;




    } )
    .catch( error => {
    console.error( 'Oops, something went wrong!' );
    console.error( 'Please, report the following error on https://github.com/ckeditor/ckeditor5/issues with the build id and the error stack trace:' );
    console.warn( 'Build id: tjg8bkmu0wpv-msj5c6xctevs' );
    console.error( error );
    } );
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.base.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\brilyyy\Projects\Laravel\temboro\resources\views/dashboard/post/create.blade.php ENDPATH**/ ?>