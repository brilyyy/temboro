<?php $__env->startSection('app'); ?>
<section class="w-full md:w-2/3 flex flex-col items-center px-3">
    <?php if(isset($post)): ?>
    <article class="flex flex-col shadow my-4">
        <!-- Article Image -->
        <a href="#" class="hover:opacity-75">
            <img src="<?php echo e($post->header); ?>">
        </a>
        <div class="bg-white flex flex-col justify-start p-6">
            <a href="<?php echo e(route('posts.by.tag', $post->tag->slug)); ?>"
                class="text-blue-700 text-sm font-bold uppercase pb-4"><?php echo e($post->tag->name); ?></a>
            <a href="<?php echo e(route('post.show', ['slug' => $post->tag->slug, 'postSlug' => $post->slug])); ?>"
                class="text-3xl font-bold hover:text-gray-700 pb-4"><?php echo e($post->title); ?></a>
            <?php echo $post->desc; ?>

        </div>
    </article>
    <?php endif; ?>

    <div class="w-full flex pt-6">
        <?php if(!empty($prev)): ?>
        <a href="<?php echo e(route('post.show', ['slug' => $post->tag->slug, 'postSlug' => $post->slug])); ?>"
            class="w-1/2 bg-white shadow hover:shadow-md text-left p-6">
            <p class="text-lg text-blue-800 font-bold flex items-center"><i class="fas fa-arrow-left pr-1"></i>
                Previous
            </p>
            <p class="pt-2"><?php echo e($prev->title); ?></p>
        </a>
        <?php endif; ?>
        <?php if(!empty($next)): ?>
        <a href="<?php echo e(route('post.show', ['slug' => $post->tag->slug, 'postSlug' => $post->slug])); ?>"
            class="w-1/2 bg-white shadow hover:shadow-md text-right p-6">
            <p class="text-lg text-blue-800 font-bold flex items-center justify-end">Next <i
                    class="fas fa-arrow-right pl-1"></i></p>
            <p class="pt-2"><?php echo e($next->title); ?></p>
        </a>
        <?php endif; ?>
    </div>

</section>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('base.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\brilyyy\Projects\Laravel\temboro\resources\views/post.blade.php ENDPATH**/ ?>