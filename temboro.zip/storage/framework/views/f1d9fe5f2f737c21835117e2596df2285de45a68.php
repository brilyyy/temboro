<?php $__env->startSection('app'); ?>

<!-- Posts Section -->
<section class="w-full md:w-2/3 flex flex-col items-center px-3">

    <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <article class="flex flex-col shadow my-4">
        <!-- Article Image -->
        <a href="#" class="hover:opacity-75">
            <img src="<?php echo e($post->header); ?>">
        </a>
        <div class="bg-white flex flex-col justify-start p-6">
            <a href="<?php echo e(route('posts.by.tag', $post->tag->slug)); ?>"
                class="text-blue-700 text-sm font-bold uppercase pb-4"><?php echo e($post->tag->name); ?></a>
            <a href="<?php echo e(route('post.show', ['slug' => $post->tag->slug, 'postSlug' => $post->slug])); ?>"
                class="text-3xl font-bold hover:text-gray-700 pb-2"><?php echo e($post->title); ?></a>
            <a href="<?php echo e(route('post.show', ['slug' => $post->tag->slug, 'postSlug' => $post->slug])); ?>" class="pb-6"><?php echo \Illuminate\Support\Str::limit($post->desc, 250, '...'); ?>

            </a>
            <hr>
            <a href="<?php echo e(route('post.show', ['slug' => $post->tag->slug, 'postSlug' => $post->slug])); ?>"
                class="uppercase text-gray-800 hover:text-black mt-6">Continue Reading <i
                    class="fas fa-arrow-right"></i></a>
        </div>
    </article>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="min-h-screen">
        <div class="flex flex-col shadow my-4 p-20">
            <h1>Belum ada postingan.</h1>
        </div>
    </div>
    <?php endif; ?>


    <?php if(!$posts->isEmpty()): ?>
    <!-- Pagination -->
    <div class="flex items-center py-8">
        <?php echo $posts->links(); ?>

    </div>

    <?php endif; ?>
</section>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('base.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\brilyyy\Projects\Laravel\temboro\resources\views/index.blade.php ENDPATH**/ ?>