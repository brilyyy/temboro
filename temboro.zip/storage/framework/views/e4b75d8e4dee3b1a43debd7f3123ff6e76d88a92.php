<?php $__env->startSection('content'); ?>
<h1 class="mt-4">All Posts</h1>
<ol class="breadcrumb mb-4">
    <li class="breadcrumb-item active">Post</li>
</ol>

<div class="card mb-4">
    <div class="card-header">
        <i class="fas fa-table me-1"></i>
        All Posts
    </div>
    <div class="card-body">
        <table id="datatablesSimple">
            <thead>
                <tr>
                    <th>No.</th>
                    <th>Header</th>
                    <th>Title</th>
                    <th>Category</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <?php echo e($post->number); ?>

                    </td>
                    <td>
                        <img src="<?php echo e(asset($post->header)); ?>" alt="header" width="150">
                    </td>
                    <td>
                        <?php echo e($post->title); ?>

                    </td>
                    <td>
                        <?php echo e($post->tag->name); ?>

                    </td>
                    <td>
                        actions
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.base.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\brilyyy\Projects\Laravel\temboro\resources\views/dashboard/post/all-post.blade.php ENDPATH**/ ?>